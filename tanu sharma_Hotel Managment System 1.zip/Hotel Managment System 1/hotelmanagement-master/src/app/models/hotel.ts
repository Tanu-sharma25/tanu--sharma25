export class Hotel {
  name: any;
  description: any;
  published?: boolean;
}
